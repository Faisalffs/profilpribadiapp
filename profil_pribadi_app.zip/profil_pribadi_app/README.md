# Profil Pribadi App

Aplikasi Flutter sederhana untuk menampilkan profil pribadi.

## Fitur
- Foto profil (CircleAvatar)
- Nama lengkap
- Deskripsi singkat
- Tombol untuk menampilkan pesan Snackbar

## Cara Menjalankan
1. Jalankan perintah `flutter pub get`
2. Jalankan aplikasi dengan `flutter run`

Dibuat oleh: Ahmad Faisal Assaudi
